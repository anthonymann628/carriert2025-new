DROP TABLE "addressdetaillist";

DROP TABLE "addressdetailproducts";

DROP TABLE "breadcrumbs";

DROP TABLE "itemvalues";

DROP TABLE "logins";

DROP TABLE "photos";

DROP TABLE "routelist";

DROP TABLE "routelistactivity";

DROP TABLE "signatures";

DROP TABLE "streetsummarylist";

DROP TABLE "uploadlog";

DROP TABLE "workactivity";